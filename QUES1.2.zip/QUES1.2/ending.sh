#! /bin/bash

cd
rm -rf A B C