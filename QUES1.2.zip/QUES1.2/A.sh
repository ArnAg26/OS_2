#! /bin/bash

cd
cd A
cd linux-5.19.9
make
