#! /bin/bash

cd
cd B
cd linux-5.19.9
make