#! /bin/bash

cd
cd C
cd linux-5.19.9
make